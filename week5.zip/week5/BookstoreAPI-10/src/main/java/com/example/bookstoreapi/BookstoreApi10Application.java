package com.example.bookstoreapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApi10Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApi10Application.class, args);
	}

}
